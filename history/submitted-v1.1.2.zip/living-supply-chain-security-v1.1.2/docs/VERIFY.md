# Verification — v1.1.1

From the repository root:

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r src/living_supply_chain_security_battery_v1_1_1/requirements.txt
python src/living_supply_chain_security_battery_v1_1_1/run_all.py
python tools/check_mutations.py
```

Expected battery tail:

```text
VERDICT: PASS
TESTS: 107  PASS: 107  FAIL: 0  ERROR: 0  SKIP: 0
CLAIMS: 10  CLAIMS PASS: 10  MATRIX MISSING: 0
```

The receipt SHA-256 will differ from sealed v1.1.0 (`ebca7546…`) because the
source manifest and mapped tests changed. Record the new digest from
`reports/execution_receipt.txt` after a clean run.

Expected mutation tool: verdict PASS, `baseline_unchanged: true`, 9/9 caught.

Copy LICENSE/NOTICE from v1.1.0 before tagging a public release.
