# Claim boundary — v1.1.1

v1.1.1 adds one bound: raw-state sibling keys that confused adapters in
v1.1.0 cannot be committed. PASS still means the named tests passed, not
a formal proof or production certification.

Consume `living_ai_bom()` or the exact field names `organs` and `maturity`.
Do not casefold or walk every raw state key as inventory.

---

# Claim boundary — v1.1

## What the current PASS establishes

The supplied reference implementation passed its 100 named tests and ten
mapped claim groups at the source hashes in this release. This includes 33
new regression tests for commit policy, authority pinning, and temporal BOM
history. Nine bounded enforcement mutations were caught by named tests on
disposable copies. The test results are recorded in VALIDATION.md.

The exercised cases include exact authorization binding and replay checks,
configured authority identity/key enforcement, commit-time import eligibility
and byte checks, protected update paths, and audit history across repeated
state digests. These statements are limited to the included tests and API.

## What changed from v1

The original allowed a signed juvenile/high-use import through `commit()` even
though its policy helper reported it ineligible. It also truncated the current
BOM's history at the first occurrence of a repeated state digest. Those failures
now have direct commit/export regression tests.

The original accepted an unpinned authority object at construction. The current
constructor requires trusted authority ID and key pins, checks the supplied
object against them, and builds an independent verifier from the configured key.
The constructor no longer trusts supplied verification behavior or subsequent
changes to the supplied object.

These are repairs in a separately versioned implementation. The original source
and its documentation remain unchanged inside the archived original ZIP.

## Trust and deployment assumptions

- **The pins and constructor are trusted.** The governed system must not choose
  its own expected authority ID/key or replace enforcement code. Merely copying
  a candidate's public key into the expected-key argument is not pinning to an
  independent trust source. The initial state is also trusted deployment input.
- **The test key is public.** The deterministic Ed25519 fixture key is only for
  reproducible tests. Production signing keys need protected external custody.
- **This is an inventory/state-transition engine.** Imported bytes are checked
  against the signed metadata, but this package does not execute modules or
  implement a durable artifact store. Restores use known snapshots from trusted
  initial state and successful commits. Actual byte retrieval/loading after
  restoration or restart remains the deployment adapter's responsibility.
- **History is local.** Hash chaining is not an external transparency log. A
  party able to rewrite the full local store is outside this threat model.
- **Time and replay tracking are local to an engine instance.** The clock
  detects rollback during a run. Production expiry, recovery, cross-instance
  replay protection, and consensus require additional deployment mechanisms.
- **Persistence tests are bounded.** The hook tests establish the stated
  in-memory behavior after failures. They do not implement or certify a
  transactional database or crash-recovery protocol.
- **Evidence validation is structural.** Declared identifiers, detector names,
  and digests do not independently establish the truth of supplied evidence.
  The large-accumulation test uses 100,000 additions, not mathematical infinity.
- **Exports are reference formats.** No in-toto, SPDX, or CycloneDX conformance
  certification is claimed. Living-AI-BOM 0.2 adds explicit commit sequences;
  a state digest alone selects the latest occurrence of those bytes.
- **Tests are not a proof.** These cases and mutations are not an exhaustive
  security analysis or production certification. Historical implementations
  are not made safe by a PASS of this reference implementation.

## Provenance and reproduction

The original uploaded ZIP is preserved byte-for-byte with its original 21-file
source manifest and 67-test receipt. Its README reports earlier reproduction
runs; this revision does not independently authenticate those historical runs.

The v1.1 receipt applies only to the new source manifest and outcomes. A matching
receipt is evidence that those bytes and recorded outcomes reproduced. It does
not show that every important attack was tested or that another author would
have chosen the same tests.

## Licensing

The provided LICENSE and licensor attribution are retained. The release uses
BUSL-1.1 with the supplied change date and change license. Prior publication and
any earlier grants still need to be assessed against their own provenance;
this revision does not resolve them or claim that a software license protects
an architectural idea itself.
