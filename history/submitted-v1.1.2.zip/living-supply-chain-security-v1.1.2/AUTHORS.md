# Authorship and provenance

**Architecture, governing invariants, and paper:** Rusty Williams McMurray  
**Project:** Living Supply-Chain Security for Persistent AI Organisms  
**Original battery:** v1, frozen July 5, 2026  
**v1.1.0 revision:** September 2, 2026  
**Current revision:** v1.1.1, September 2, 2026

v1.1.1 is a tightening of the v1.1.0 reference implementation. It refuses
signed `set` writes that plant undeclared state roots or shadow `organs` /
`maturity` (including case and NFKC aliases). Architectural authorship and
executable test evidence remain distinct.

The sealed v1.1.0 receipt (`ebca7546…`) is historical. This revision has its
own source manifest and receipt.
