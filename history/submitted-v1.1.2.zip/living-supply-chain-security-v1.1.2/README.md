# Living Supply-Chain Security v1.1.2

An executable reference for an enforcement layer around systems that update
their own state, configuration, or capability inventory.

**The rule:** a system may propose a change. Commitment requires an external
signed authorization bound to that exact transition.

This tree is **v1.1.2**, a tightening of v1.1.0. Publish v1.1.0 from its own
repository tonight; do not mix the two receipts.

## What 1.1.2 fixes

v1.1.0 allowed a *signed* generic `set` to create extra top-level keys
(`Organs`, `Maturity`, `capabilities`, homoglyphs) and `personality.organs`.
The engine and `living_ai_bom()` ignored those keys, but a raw-state adapter
that casefolded or walked every field could be fooled.

v1.1.2 refuses those writes. Authorization is still required. The organism
still cannot sign for itself.

## Verify

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r src/living_supply_chain_security_battery_v1_1_1/requirements.txt
python src/living_supply_chain_security_battery_v1_1_1/run_all.py
python tools/check_mutations.py
```

Expected battery result: **107 passed**, 10/10 claim groups, exit 0.
Expected mutation result: **PASS**, `baseline_unchanged: true`, 9/9 caught.

Copy `LICENSE` and `NOTICE` from the v1.1.0 repo before publishing. They were
not in the 1.1.2 working set used to build this tree.

## Layout

| Path | Purpose |
|---|---|
| `src/living_supply_chain_security_battery_v1_1_1/` | Code, tests, matrix, runner |
| `tools/check_mutations.py` | Nine bounded enforcement mutations |
| `docs/` | Verify, claim boundary, validation notes |
| `CHANGELOG.md` | 1.1.2 and inherited 1.1.0 notes |

## Claims

Same ten groups as v1.1.0. State-schema regressions are mapped into INV-6 and
MATURITY-IMPORT.

Architecture and paper: **Rusty Williams McMurray**.
