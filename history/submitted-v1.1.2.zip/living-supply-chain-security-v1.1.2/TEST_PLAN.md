# Claim-facing test plan — v1.1.1

Inherits the v1.1 plan (100 tests, ten claim groups) and adds state-schema
refusals for sibling inventory keys and undeclared roots.

## Added in 1.1.1

Authorized `set` must not:

- write `Organs` / `Maturity` / case variants of protected roots
- create unknown top-level fields
- shadow inventory names under `personality`
- change the `policy` label via generic `set`

Legitimate `set` of `["personality", "verbosity"]` must still commit with
exact external authorization.
