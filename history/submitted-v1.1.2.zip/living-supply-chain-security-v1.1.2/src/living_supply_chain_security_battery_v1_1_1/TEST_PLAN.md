# Claim-facing test plan — v1.1.1

v1.1.1 keeps the v1.1.0 plan and adds state-schema regressions so raw-state
consumers cannot be fed sibling inventory or maturity keys.

## Added in 1.1.1

Refuse signed `set` paths that are not under exact `personality`. Refuse
`Organs` / `Maturity` aliases, unknown roots, homoglyph roots, policy-label
rewrites, and `personality.organs` shadowing. Resulting state may only contain
`maturity`, `personality`, `organs`, and `policy`.

## Inherited from v1.1.0

Invariants 1–6, exact Minato binding, commit-time import policy, temporal BOM
snapshots, and the cold-fence rule are unchanged.
