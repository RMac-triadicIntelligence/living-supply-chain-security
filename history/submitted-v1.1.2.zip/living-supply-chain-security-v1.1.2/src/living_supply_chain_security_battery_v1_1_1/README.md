# Living Supply-Chain Security Falsification Battery v1.1.1

**Version:** 1.1.1, September 2, 2026  
**Paper:** Living Supply-Chain Security for Persistent AI Organisms  
**Principle:** A system may propose a change; authorization comes from an external signer.

This revision tightens state shape on top of v1.1.0. Signed `set` operations
may only write under exact `personality`. Sibling keys such as `Organs`,
`Maturity`, homoglyph roots, and `personality.organs` cannot be committed.
`living_ai_bom()` and raw `eng.state` now stay aligned on inventory roots.

The sealed v1.1.0 receipt does not apply to this revision.

## Run

From this battery directory:

```bash
python -m pip install -r requirements.txt
python run_all.py
```

## API added in 1.1.1

`CommitEngine` rejects:

- `set` whose first path element is not exactly `personality`
- path elements that NFKC-casefold to `organs` or `maturity`
- resulting states with roots outside `{maturity, personality, organs, policy}`
- personality fields that shadow protected inventory names

v1.1.0 constructor pins, `commit(..., artifact=)`, and `living_ai_bom(..., sequence=)`
are unchanged. Policy identifier remains `LIVING-SCS-POLICY-V1.1`.

## Tests

107 tests: the original 100 from v1.1.0 plus 7 state-schema regressions.
